﻿namespace Push.Shopify.Http.Credentials
{
    public interface IShopifyCredentials
    {
        ShopDomain Domain { get; }
    }
}
