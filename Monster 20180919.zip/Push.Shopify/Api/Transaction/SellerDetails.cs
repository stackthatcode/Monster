﻿namespace Push.Shopify.Api.Transaction
{
    public class SellerDetails
    {
        public string SecureMerchantAccountID { get; set; }
    }
}
