namespace Push.Shopify.Api.Order
{
    public class DiscountCode
    {
        public string code { get; set; }
        public string amount { get; set; }
        public string type { get; set; }
    }
}