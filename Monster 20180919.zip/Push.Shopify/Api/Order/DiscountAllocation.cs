namespace Push.Shopify.Api.Order
{
    public class DiscountAllocation
    {
        public decimal amount { get; set; }
        public int discount_application_index { get; set; }
    }
}
