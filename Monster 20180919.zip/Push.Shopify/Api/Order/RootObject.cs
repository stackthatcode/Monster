namespace Push.Shopify.Api.Order
{
    public class RootObject
    {
        public Order order { get; set; }
    }
}