namespace Push.Shopify.Api.Order
{
    public class Receipt
    {
        public string paid_amount { get; set; }
    }
}