namespace Push.Shopify.Api.Order
{
    public class TaxLine
    {        
        public decimal price { get; set; }
        public decimal rate { get; set; }
        public string title { get; set; }
    }
}
