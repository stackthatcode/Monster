﻿namespace Push.Foundation.Utilities.Logging
{
    public interface ILogFormatter
    {
        string Do(string message);
    }
}
